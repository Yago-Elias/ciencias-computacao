/* Autor: Alex Martins - josealex.pm@gmail.com 
*  Códigos base: https://www.ime.usp.br/~pf/algoritmos_para_grafos/
*  Implementações de exercícios e personalização de programas.
*  Compilar: gcc -o main main.c matrix_basic.c
*  Lista mínima de arquivos (main.c, list_basic.h, list_basic.c)
*/

#include "matrix_basic.h"

int main(){

	Graph G;

	G = GRAPHinit(5);
	GRAPHinsertArc(G, 0, 1);
	GRAPHinsertArc(G, 1, 2);
	GRAPHinsertArc(G, 2, 3);

	GRAPHshow(G);

	return 0;
}