#ifndef _LIST_H
#define _LIST_H

#define vertex int

struct graph {
   int V; 
   int A; 
   int **adj; 
};

typedef struct graph *Graph;


Graph GRAPHinit( int V);
void GRAPHinsertArc( Graph G, vertex v, vertex w);
void GRAPHshow( Graph G);
Graph GRAPHrand( int V, int A);

#endif